﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathQuiz
{
    public partial class MainForm : Form
    {
        bool           isGameRunning  = false;                // Whether a quiz is in progress or not
        CalculatorForm calculatorForm = new CalculatorForm(); // Calculator form
        HelpForm       helpForm       = new HelpForm();       // Help form
        Random         random         = new Random();         // The main random engine

        QuizPart[] quizList = new QuizPart[4];

        int timeRemaining = 120;

        private void startMenu_Click(object sender, EventArgs e)
        {
            StartQuiz();
        }

        private void mainTimer_Tick(object sender, EventArgs e)
        {
            timeRemaining--;
            int timeTemp = timeRemaining < 0 ? -timeRemaining : timeRemaining;
            timeLabel.Text = $"Time: " + (timeRemaining < 0 ? "-" : "0") + (timeTemp / 60) + (timeTemp % 60 < 10 ? ":0" : ":") + (timeTemp % 60);
            if (timeRemaining <= 0)
            {
                timeLabel.BackColor = Color.Red;
                timeLabel.ForeColor = Color.White;
            }
            else if (timeRemaining <= 10)
            {
                timeLabel.BackColor = Color.Orange;
                timeLabel.ForeColor = Color.Black;
            }
            else if (timeRemaining <= 30)
            {
                timeLabel.BackColor = Color.Yellow;
                timeLabel.ForeColor = Color.Black;
            }
            else if (timeRemaining <= 60)
            {
                timeLabel.BackColor = Color.YellowGreen;
                timeLabel.ForeColor = Color.Black;
            }
            else
            {
                timeLabel.BackColor = Color.Green;
                timeLabel.ForeColor = Color.White;
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (!isGameRunning) StartQuiz();
            else
            {
                // Here the start quiz button acts as a submit button
                int i, wrong;
                for (i = 0, wrong = 0; i < 4; i++)
                {
                    switch(i)
                    {
                        case 0:
                            if (quizList[0].Num1 + quizList[0].Num2 != quizList[0].NumericResult.Value)
                                goto helpLabel;
                            break;
                        case 1:
                            if (quizList[1].Num1 - quizList[1].Num2 != quizList[1].NumericResult.Value)
                                goto helpLabel;
                            break;
                        case 2:
                            if (quizList[2].Num1 * quizList[2].Num2 != quizList[2].NumericResult.Value)
                                goto helpLabel;
                            break;
                        case 3:
                            if (quizList[3].Num1 / quizList[3].Num2 != quizList[3].NumericResult.Value)
                                goto helpLabel;
                            break;
                            helpLabel:
                            wrong++;
                            MessageBox.Show("There's a mistake");
                            // ... Add help message here ...
                            break;
                    }

                    if (wrong > 0) break;
                }

                
                if (wrong == 0)
                {
                    if (timeRemaining > 0)
                        StartNewQuiz();
                    else
                    {
                        // ...Add statistics code here...
                        EndQuiz();
                    }
                }
            }
        }

        private void StartQuiz()
        {
            isGameRunning = true;
            mainTimer.Enabled = true;
            for (int i = 0; i < 4; i++) quizList[i].Enabled = true;
            startMenu.Visible = false;
            stopMenu.Visible = true;
            quizHelpMenu.Visible = true;
            startButton.Text = "Submit Answers";
            timeLabel.Text = "Time: 02:00";
            timeLabel.BackColor = Color.Green;
            timeLabel.ForeColor = Color.White;
            calculatorButton.Enabled = true;
            StartNewQuiz();
        }

        private void EndQuiz()
        {
            calculatorForm.Hide();

            isGameRunning = false;
            mainTimer.Enabled = false;
            timeRemaining = 120;
            for (int i = 0; i < 4; i++) quizList[i].Enabled = false;
            startMenu.Visible = true;
            stopMenu.Visible = false;
            quizHelpMenu.Visible = false;
            startButton.Text = "Start the Quiz";
            timeLabel.Text = "Time: 00:00";
            timeLabel.BackColor = Color.Transparent;
            timeLabel.ForeColor = Color.Black;
            calculatorButton.Enabled = false;            
        }

        private void StartNewQuiz()
        {
            for (int i = 0; i < 3; i++)
            {
                quizList[i].Num1 = random.Next(-300, 300);
                do
                {
                    quizList[i].Num2 = random.Next(-300, 300);
                } while (quizList[i].Num2 == 0);
                quizList[i].NumericResult.Value = 0;
            }
            quizList[3].Num2 = random.Next(-300, 300);
            quizList[3].Num1 = random.Next(-300, 300) * quizList[3].Num2;
            quizList[3].NumericResult.Value = 0;
        }


        private void exitMenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        public MainForm()
        {
            InitializeComponent();

            quizList[0] = new QuizPart("+", false); // Addition
            quizList[1] = new QuizPart("-", false); // Subtraction
            quizList[2] = new QuizPart("x", false); // Multiplication
            quizList[3] = new QuizPart(":", true);  // Division

            // Position the elements in the form
            for (int i = 0; i < 4; i++)
            {
                quizList[i].Location = new Point(ClientRectangle.X + 12, ClientRectangle.Y + mainMenuStrip.Height + 12 + i * 30);
                quizList[i].Enabled = false;
                Controls.Add(quizList[i].LabelNum1);
                Controls.Add(quizList[i].LabelNum2);
                Controls.Add(quizList[i].LabelSymbol);
                Controls.Add(quizList[i].LabelEqual);
                Controls.Add(quizList[i].NumericResult);
            }
        }

      

        

        private void Correctio(object sender, EventArgs e)
        {
            NumericUpDown answerBox = sender as NumericUpDown;
            if(answerBox!= null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);

            }
        }

        private bool Validity()
        {
            /*
            if(( add1 + add2 == Addition.Value)&&(min1 - min2 == Subtraction.Value)&&(mult1 * mult2 == Multiplication.Value)&&(div1/div2 == Division.Value))
            {
                statistic = 100;
                return true;
            }
            else
            {
                return false;
            }
            */
            return true;
        }

        private void calculatorButton_Click(object sender, EventArgs e)
        {
            calculatorForm.Show();
        }

        private void calculatorMenu_Click(object sender, EventArgs e)
        {
            calculatorForm.Show();
        }

        private void stopMenu_Click(object sender, EventArgs e)
        {
            EndQuiz();
        }
    }
}
